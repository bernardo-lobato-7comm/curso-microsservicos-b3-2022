# spring-cloud-config-configuration

Configurações do projeto : https://github.com/emmanuelneri-blog/spring-cloud-config
