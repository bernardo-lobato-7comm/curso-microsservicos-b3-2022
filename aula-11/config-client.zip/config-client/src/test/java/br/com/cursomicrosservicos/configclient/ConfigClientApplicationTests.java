package br.com.cursomicrosservicos.configclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
